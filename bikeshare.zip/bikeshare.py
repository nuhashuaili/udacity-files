import time
import pandas as pd
import numpy as np

#data file names
CITY_DATA = { 'chicago': 'chicago.csv',
            'new york city': 'new_york_city.csv',
            'washington': 'washington.csv' }
#common phrases
ph = {'error': '\nValue Error. Would you like to try again? (yes/no)\n', 'not avail': 
            '\nThe value you have chosen is not available. Would you like to try again (yes/no)?\n',
            'menu':'\nReturning to menu','show':'\nShowing data from: ','Exit':'\nExiting programme'}
line = '='*40

# defining global variables to avoid errors
city = None
month = None
day = None
df = None
rawdf = None

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.
    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    
    #user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs


    
    while True:
        
        try:
            city = str(input('\nChoose a city:\n(Chicago\ New York City\ Washington\ back)\n ')).lower().strip()
                                   
        except ValueError:
            cont1=str(input(ph['error'])).lower().strip()
        
        except KeyboardInterrupt:
            print(ph['menu'])
            main()
            break
            
                       
        if city == 'chicago' or city == 'new york city' or city == 'washington': 
            print(ph['show'] +city)
            break

        elif city == 'back':
            print(ph['menu'])
            main()
            break  
                  
        else:
            cont1=input(ph['not avail']).lower().strip()
    
        if cont1 != 'yes':
            print(ph['menu'])
            main()
            break  
        
                

    # TO DO: get user input for month (all, january, february, ... , june)
    while True:
        try:
            month = int(input('Choose a month (0-12)(0 = all): '))
                        
        except ValueError:
            cont2 = str(input(ph['error'])).lower().strip()
        
        except KeyboardInterrupt:
            print(ph['menu'])
            main()
            break
            
        if month not in range(13):  # making the programme more interactive and catching typing errors
            cont2 = input(ph['not avail']).lower().strip()
        
        else:
            months=['all','January','February','March','April','May','June','July',
                    'August','September','October','November','December']                
            print(ph['show'] + months[month]) 
            month = months[month]
            break

        if cont2 != 'yes':
            print(ph['menu'])
            main()
            break
        
    # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)
    while True:
        try:
            day = int(input('Choose a day of the week (0-7)(0 = all): '))
            
        except ValueError:
            cont3=str(input(ph['error'])).lower().strip()
        
        except KeyboardInterrupt:
            print(ph['menu'])
            main()
            break
        
        if day not in range(8):
            cont3 = input(ph['not avail']).lower().strip()
                
        else:
            days = ['all','Monday','Tuesday','Wednesday','Tursday','Friday','Saturday','Sunday']
            print(ph['show'] + days[day])
            day = days[day]
            break

        if cont3 != 'yes':
            print(ph['menu'])
            main()
            break
            
    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """

    
    # extracting data
    rawdf = pd.read_csv(CITY_DATA[city])

    # removing rows with NAN values

    df = rawdf.dropna(axis = 0)

    #convering the times and dates into datetime format
    df['Start Time'] = pd.to_datetime(df['Start Time'])  
    df['End Time'] = pd.to_datetime(df['End Time']) 

    #creating a month column
    df['Month'] = df['Start Time'].dt.month

    # #creating a date column
    df['day_of_week'] = df['Start Time'].dt.dayofweek
        
    #filtering by month
    if month != 'all':   
        months = ['January','February','March','April','May','June','July',
                        'August','September','October','November','December']
        month = months.index(month)+1    
        df = df[df['Month'] == month]
       
    #filtering by day
    if day != 'all':
        days = ['Monday','Tuesday','Wednesday','Tursday','Friday','Saturday','Sunday']
        day = days.index(day)+1
        df = df[df['day_of_week'] == day]
        
    return rawdf, df



def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    #the most common month
    commonmonth = df['Month'].mode()[0]
    months = ['January','February','March','April','May','June','July',
                        'August','September','October','November','December']
    
    commonmonth = months[commonmonth-1]

    print('The most common month for travel is: {}'.format(commonmonth))

    #the most common day of week

    commonday = df['day_of_week'].mode()[0]
    days = ['Monday','Tuesday','Wednesday','Tursday','Friday','Saturday','Sunday']
    commonday = days[commonday-1]
    print('The most common day of week for travel is: {}'.format(commonday))

    #the most common start hour
    commonhour= df['Start Time'].dt.hour
    print('The most common start hour for travel is: {}'.format(commonhour.mode()[0]))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    
    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # most commonly used start station
    print('The most commonly used start station is: {}'.format(df['Start Station'].mode()[0]))

    # most commonly used end station
    print('The most commonly used end station is: {}'.format(df['End Station'] .mode()[0]))

    # the most frequent combination of start station and end station trip
    print('The most frequent combination of start and end stations is: {}'.format(df.groupby(['Start Station','End Station']).size().idxmax()))
    
    #second solution
    #startend= df['Start Station']+' and '+ df['End Station']
    #print('The most frequent combination of start and end stations is: {}'.format(startend.mode()[0]))
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""
    
    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    #total travel time
    
    traveltime = df['End Time'] - df['Start Time'] #calculating the travel time
    
    print('Total travel time:\n{}'.format(traveltime))

    #display mean travel time
    print('\nMean travel time:\n{}'.format(traveltime.mean()))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats(df,city):
    """Displays statistics on bikeshare users."""
    
    print('\nCalculating User Stats...\n')
    start_time = time.time()

    #counts of user types
    print('User type counts:\n{}'.format(df['User Type'].value_counts()) + '\n')
    
    if city != 'washington':
        #  counts of gender
        print('Counts of gender:\n{}'.format(df['Gender'].value_counts())+ '\n') 
        # earliest, most recent, and most common year of birth
        print('Earliest birth date: {}'.format(df['Birth Year'].min()))
        print('Most recent birth date: {}'.format(df['Birth Year'].max()))
        print('Most common year of birth: {}'.format(df['Birth Year'].mode()))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def raw_data_iterator(rawdf):
    """ This function displays 5 rows of raw data at a time """
       
    print('\nShowing raw data...\n')

    print(rawdf.head())
    count = 5
    pdshape = len(rawdf) #number of rows

    while True:

        try:
            i =input('Would you like to view 5 more rows of data (yes/no)? ').lower().strip()
            dif = len(rawdf)-count

        except ValueError:
            print(ph['error'])
            continue

        if dif < 5: # last few rows
            print(rawdf.iloc[count: ])
            print('\nEnd of pandas no more data to display.\nReturning to main manu')
            break
            

        if i == 'yes' and count < pdshape:
            print(rawdf.iloc[count:(count+5)])
            count += 5
            continue


        elif count >= pdshape:
            print('\nEnd of pandas no more data to display.\nReturning to main manu')
            break

        elif i != 'yes':
            print('\nReturning to main menu.')
            break
    
    print('-'*40)


def main():

    while True:
        try: 
            n = str(input('Hello! Let\'s explore some US bikeshare data!\nWould you like to continue (yes/no)? ')).lower().strip()

        except ValueError:
            n = print(ph['error'])

        if n == 'yes':
            
            while True:
                city, month, day = get_filters()
                rawdf, df = load_data(city, month, day)
                try: 
                    option = int(input('\nChoose an option:\n1. Time Stats\n2. Station Stats\n3. Trip Duration Stats'+
                                    '\n4. User Stats\n5. View Raw Data\n6. Restart\n7.Exit\n'))
                except ValueError:
                    print('Oops! It seems like you\'ve entered an invalid data type.\n Returning to main menu.')
                    continue
                except KeyboardInterrupt:
                    print(ph['exit']) 
                    break           
                # options
                if option == 1:                   
                    print('\n'+line)
                    time_stats(df)
                    continue
                elif option == 2:
                    print('\n'+line)
                    station_stats(df)
                    continue
                elif option == 3:
                    print('\n'+line)
                    trip_duration_stats(df)
                    continue
                elif option == 4:
                    print('\n'+line)   
                    user_stats(df,city)
                    continue
                elif option == 5:
                    print('\n'+line)
                    raw_data_iterator(rawdf)
                    continue             
                elif option == 6:
                    print('\n'+line)
                    print('\nRestarting\n')
                    continue
                else: 
                    print('\n'+line)
                    print(ph['exit']) 
                    break            

        else:
            print('\n'+line)
            print(ph['exit'])
            break

        

    
if __name__ == "__main__":
	main()
